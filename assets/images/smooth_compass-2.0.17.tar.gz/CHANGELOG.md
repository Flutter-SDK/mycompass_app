## 2.0.17
* Error customization for qiblah added

## 2.0.14
* qiblah direction added

## 2.0.4
* showing default widget initially while using custom widget --Fixed

## 2.0.2
* documentation updated

## 2.0.0
* documentation updated
* simplified code
* issues resolution
* up to date

## 1.0.6
* analysis warnings fixed
